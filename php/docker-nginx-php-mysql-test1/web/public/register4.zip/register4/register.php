<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Status</h2>
	</div>
	<form method="post" action="server.php" enctype="multipart/form-data">
		<p>
			Completed | ثبت نام انجام شد منتظر پیگیری و تماس ما باشید - تشکر
		</p>
		<div class="input-group">
			<button type="submit" class="btn" name="new_form">New Form | ثبت نام جدید</button>
		</div>
	</form>
</body>
</html>
