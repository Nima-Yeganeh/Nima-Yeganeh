# registration
PHP registration with mysql
Info >> User Info
Commands >> Register
Database Info >> db:register4 (root/root) - host:mysql
NGINX CGI >> Cache Config
Image (PNG/JPG/GIF) File Upload >> Configured >> server.php
